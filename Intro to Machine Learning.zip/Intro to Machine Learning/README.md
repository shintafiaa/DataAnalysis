# Kampus-Merdeka-ML-Pemula
Belajar dasar-dasar machine learning
